plugins { id("com.android.application") }

android {
    namespace = "ro.noadsx15.hybrid"
    compileSdk = 35
    defaultConfig {
        applicationId = "ro.noadsx15.hybrid"
        minSdk = 29
        targetSdk = 35
        versionCode = 41
        versionName = "4.1.0"
        testInstrumentationRunner = "android.test.InstrumentationTestRunner"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies { testImplementation("junit:junit:4.13.2") }
